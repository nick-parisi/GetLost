/** Automatically generated file. DO NOT MODIFY */
package edu.bc.cs.parisin.cs344s14.getlost;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}